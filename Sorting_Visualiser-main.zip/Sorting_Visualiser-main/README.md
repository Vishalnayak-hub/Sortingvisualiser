This website will make users to visualise various sorting techniques.
Technologies_used: HTML,CSS,JavaScript;

Demo You can access the live demo of the application by going through the link given below

([https://drive.google.com/file/d/1QaliFpk8UcFbUQlt2kGJZfQpD-2XJYlW/view?usp=share_link])

if you want to visit the site, you can go to link given below

([https://sorting-visualiser-mu.vercel.app])

Please feel free to explore the application and provide feedback.
